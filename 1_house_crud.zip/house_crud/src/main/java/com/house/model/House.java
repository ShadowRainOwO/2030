package com.house.model;

public class House {

    private Integer id;
    private String agriculturalAndFarmhouses;
    private String condominiums;
    private String cooperativeHomes;
    private String detachedHomes;
    private String duplexes;
    private String freeholds;
    private String highValueHomes;
    private String land;
    private String lockersAndStorage;
    private String mobileHomes;
    private String multiFamilyHomes;
    private String multiGenerational;
    private String multiLexes;
    private String newConstructions;
    private String parkingSpaces;
    private String recreationalAndVacationHomes;
    private String semiDetachedHomes;
    private String stackedTownhouses;
    private String townhouses;
    private String tripleDeckers;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAgriculturalAndFarmhouses() {
        return agriculturalAndFarmhouses;
    }

    public void setAgriculturalAndFarmhouses(String agriculturalAndFarmhouses) {
        this.agriculturalAndFarmhouses = agriculturalAndFarmhouses;
    }

    public String getCondominiums() {
        return condominiums;
    }

    public void setCondominiums(String condominiums) {
        this.condominiums = condominiums;
    }

    public String getCooperativeHomes() {
        return cooperativeHomes;
    }

    public void setCooperativeHomes(String cooperativeHomes) {
        this.cooperativeHomes = cooperativeHomes;
    }

    public String getDetachedHomes() {
        return detachedHomes;
    }

    public void setDetachedHomes(String detachedHomes) {
        this.detachedHomes = detachedHomes;
    }

    public String getDuplexes() {
        return duplexes;
    }

    public void setDuplexes(String duplexes) {
        this.duplexes = duplexes;
    }

    public String getFreeholds() {
        return freeholds;
    }

    public void setFreeholds(String freeholds) {
        this.freeholds = freeholds;
    }

    public String getHighValueHomes() {
        return highValueHomes;
    }

    public void setHighValueHomes(String highValueHomes) {
        this.highValueHomes = highValueHomes;
    }

    public String getLand() {
        return land;
    }

    public void setLand(String land) {
        this.land = land;
    }

    public String getLockersAndStorage() {
        return lockersAndStorage;
    }

    public void setLockersAndStorage(String lockersAndStorage) {
        this.lockersAndStorage = lockersAndStorage;
    }

    public String getMobileHomes() {
        return mobileHomes;
    }

    public void setMobileHomes(String mobileHomes) {
        this.mobileHomes = mobileHomes;
    }

    public String getMultiFamilyHomes() {
        return multiFamilyHomes;
    }

    public void setMultiFamilyHomes(String multiFamilyHomes) {
        this.multiFamilyHomes = multiFamilyHomes;
    }

    public String getMultiLexes() {
        return multiLexes;
    }

    public void setMultiLexes(String multiLexes) {
        this.multiLexes = multiLexes;
    }

    public String getNewConstructions() {
        return newConstructions;
    }

    public void setNewConstructions(String newConstructions) {
        this.newConstructions = newConstructions;
    }

    public String getParkingSpaces() {
        return parkingSpaces;
    }

    public void setParkingSpaces(String parkingSpaces) {
        this.parkingSpaces = parkingSpaces;
    }

    public String getRecreationalAndVacationHomes() {
        return recreationalAndVacationHomes;
    }

    public void setRecreationalAndVacationHomes(String recreationalAndVacationHomes) {
        this.recreationalAndVacationHomes = recreationalAndVacationHomes;
    }

    public String getSemiDetachedHomes() {
        return semiDetachedHomes;
    }

    public void setSemiDetachedHomes(String semiDetachedHomes) {
        this.semiDetachedHomes = semiDetachedHomes;
    }

    public String getStackedTownhouses() {
        return stackedTownhouses;
    }

    public void setStackedTownhouses(String stackedTownhouses) {
        this.stackedTownhouses = stackedTownhouses;
    }

    public String getTownhouses() {
        return townhouses;
    }

    public void setTownhouses(String townhouses) {
        this.townhouses = townhouses;
    }

    public String getTripleDeckers() {
        return tripleDeckers;
    }

    public void setTripleDeckers(String tripleDeckers) {
        this.tripleDeckers = tripleDeckers;
    }


    public String getMultiGenerational() {
        return multiGenerational;
    }

    public void setMultiGenerational(String multiGenerational) {
        this.multiGenerational = multiGenerational;
    }

    @Override
    public String toString() {
        return "House{" +
                "id=" + id +
                ", agriculturalAndFarmhouses='" + agriculturalAndFarmhouses + '\'' +
                ", condominiums='" + condominiums + '\'' +
                ", cooperativeHomes='" + cooperativeHomes + '\'' +
                ", detachedHomes='" + detachedHomes + '\'' +
                ", duplexes='" + duplexes + '\'' +
                ", freeholds='" + freeholds + '\'' +
                ", highValueHomes='" + highValueHomes + '\'' +
                ", land='" + land + '\'' +
                ", lockersAndStorage='" + lockersAndStorage + '\'' +
                ", mobileHomes='" + mobileHomes + '\'' +
                ", multiFamilyHomes='" + multiFamilyHomes + '\'' +
                ", multiGenerational='" + multiGenerational + '\'' +
                ", multiLexes='" + multiLexes + '\'' +
                ", newConstructions='" + newConstructions + '\'' +
                ", parkingSpaces='" + parkingSpaces + '\'' +
                ", recreationalAndVacationHomes='" + recreationalAndVacationHomes + '\'' +
                ", semiDetachedHomes='" + semiDetachedHomes + '\'' +
                ", stackedTownhouses='" + stackedTownhouses + '\'' +
                ", townhouses='" + townhouses + '\'' +
                ", tripleDeckers='" + tripleDeckers + '\'' +
                '}';
    }
}


