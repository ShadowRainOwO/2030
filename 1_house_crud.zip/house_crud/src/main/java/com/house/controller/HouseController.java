package com.house.controller;

import com.house.model.House;
import com.house.service.HouseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

@Controller
@RequestMapping("/house")
public class HouseController {

    @Resource
    private HouseService houseService;

    @RequestMapping("/create")
    public String createModel(House house, Model model){
        boolean b = houseService.create(house);
        if (!b){
            model.addAttribute("msg", "Add failed");
            return "editor";
        }
        return "redirect:/house/findAll";
    }

    @PostMapping("/update")
    public String updateModel(House house){
        houseService.updateById(house);
        return "redirect:/house/findAll";
    }

    @GetMapping("/update/{id}")
    public String queryOne(@PathVariable Integer id, Model model){
        House byId = houseService.findById(id);
        model.addAttribute("house", byId);
        return "editor";
    }

    @RequestMapping("/remove/{id}")
    public String removeById(@PathVariable Integer id, Model model){
        boolean b = houseService.deleteById(id);
        if (!b) {
            model.addAttribute("msg", "Deletion failed");
            return "index";
        }
        return "redirect:/house/findAll";
    }


    @RequestMapping("/findAll")
    public String findAll(Model model, String condominiums){
        model.addAttribute("houses", houseService.findAll(condominiums));
        return "index";
    }




}
