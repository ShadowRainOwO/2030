package com.house.dao;

import com.house.model.House;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Repository
public class HouseDao {

    private static final List<House> DATABASE = new ArrayList<House>();

    private static int INDEX =  0;

    public List<House> findAll(String condominiums){
        if (StringUtils.isEmpty(condominiums)){
            return DATABASE;
        }else {
            List<House> list = new ArrayList<House>();
            for (House house : DATABASE) {
                if (house.getCondominiums().contains(condominiums)){
                    list.add(house);
                }
            }
            return list;
        }
    }


    public House updateById(House house){
        for (int i = DATABASE.size() - 1; i >= 0; i--) {
            House house1 = DATABASE.get(i);
            if (house.getId().equals(house1.getId())){
               return DATABASE.set(i, house);
            }
        }
        return null;
    }


    public boolean deleteById(Integer id){
        for (int i = DATABASE.size() - 1; i >= 0; i--) {
            House house1 = DATABASE.get(i);
            if (id.equals(house1.getId())){
               return DATABASE.remove(house1);
            }
        }
        return false;
    }

    public boolean create(House house){
       house.setId(++INDEX);
       return DATABASE.add(house);
    }


    public House findById(Integer id) {
        for (int i = DATABASE.size() - 1; i >= 0; i--) {
            House house1 = DATABASE.get(i);
            if (id.equals(house1.getId())){
                return house1;
            }
        }
        return null;
    }
}
