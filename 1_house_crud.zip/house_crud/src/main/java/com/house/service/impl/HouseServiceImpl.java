package com.house.service.impl;

import com.house.dao.HouseDao;
import com.house.model.House;
import com.house.service.HouseService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.UUID;

@Service
public class HouseServiceImpl implements HouseService {

    @Resource
    private HouseDao houseDao;

    public List<House> findAll(String condominiums) {
        return houseDao.findAll(condominiums);
    }

    public void updateById(House house) {
        houseDao.updateById(house);
    }

    public boolean deleteById(Integer id) {
        return houseDao.deleteById(id);
    }

    public boolean create(House house) {
        house.setLand(UUID.randomUUID().toString());
        return houseDao.create(house);
    }

    public House findById(Integer id) {
        return houseDao.findById(id);
    }
}
