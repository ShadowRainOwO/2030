package com.house.service;

import com.house.model.House;

import java.util.List;

public interface HouseService {

    List<House> findAll(String condominiums);


    void updateById(House house);


    boolean deleteById(Integer id);

    boolean create(House house);


    House findById(Integer id);
}
