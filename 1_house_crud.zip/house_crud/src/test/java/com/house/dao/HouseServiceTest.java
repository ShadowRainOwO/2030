package com.house.dao;

import com.house.model.House;
import com.house.service.HouseService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.annotation.Resource;
import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring-config.xml", "classpath:springmvc-config.xml"})
public class HouseServiceTest {

    @Resource
    private HouseService houseService;


    @Test
    public void create() {
        boolean b1 = houseService.create(new House());
        boolean b2 = houseService.create(new House());
        assert b1 && b2;
    }


    @Test
    public void deleteById() {
        boolean b = houseService.deleteById(1);
        assert b;
    }

    @Test
    public void findById() {
        House byId = houseService.findById(2);
        assert byId != null;
    }

    @Test
    public void findAll() {
        List<House> all = houseService.findAll("");
        assert all.size() > 0;
    }
}